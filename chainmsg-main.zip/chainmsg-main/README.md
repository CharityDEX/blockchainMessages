# Chainmsg

## Development

```sh
pnpm contracts:node
```

```sh
pnpm contracts:deploy:locahost
```

```sh
pnpm dev
```

## Deployment

```sh
source .env && pnpm contracts:deploy --network production
```
